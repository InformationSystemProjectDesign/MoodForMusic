"""MusicMain URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from musicApp import views
# from django.contrib.auth import views

urlpatterns = [
    path('admin/', admin.site.urls), #管理者後台
    path('', views.acct_login, name="acct_login"), #登入
    path('acct_login/', views.acct_login, name="acct_login"), #登入
    path('index/', views.index, name="index"), #首頁
    path('mailCon/<int:articleid>/', views.mailCon, name="mailCon"), # 公告欄的其中一個信件內容
    path('mailContent/<int:articleid>/', views.mailContent, name="mailContent"), #個人的其中一個信件內容 
    path('draftRecord/', views.draftRecord, name="draftRecord"), #草稿記錄
    path('draftsend/<str:mtype>/', views.draftsend), #草稿送出
    path('pBoard/', views.pBoard, name="pBoard"), #公告欄
    path('pFile/', views.pFile, name="pFile"), #個人檔案(修改密碼)
    path('pFileMood/', views.pFileMood, name="pFileMood"), #個人情緒圖
    path('pAllMood/', views.PAllMood, name="pAllMood"), #整體情緒圖
    path('pMailRecord/', views.pMailRecord, name="pMailRecord"), #信件紀錄
    # path('pMessage/', views.pMessage, name="pMessage"), #個人的留言回覆紀錄，先跳過
    path('profile/', views.profile, name="profile"), #個人首頁(個人天地)
    path('pWrite/', views.pWrite, name="pWrite"), #個人寫信 <int:writeid>/
    path('dWrite/<int:articleid>/', views.dWrite, name="dWrite"), #個人草稿的其中一個編輯畫面
    # path('resultMsg/', views.resultMsg, name="resultMsg"), #送出後跳出的視窗(待定，先跳過)
    path('signPage/', views.signPage, name="signPage") #註冊頁面
]
