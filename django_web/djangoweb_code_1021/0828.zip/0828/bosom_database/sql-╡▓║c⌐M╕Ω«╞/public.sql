/*
 Navicat Premium Data Transfer

 Source Server         : bosomTest(d68ejc1qf6f9fd)
 Source Server Type    : PostgreSQL
 Source Server Version : 140004
 Source Host           : ec2-23-23-151-191.compute-1.amazonaws.com:5432
 Source Catalog        : d68ejc1qf6f9fd
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 140004
 File Encoding         : 65001

 Date: 28/08/2022 19:06:17
*/


-- ----------------------------
-- Sequence structure for auth_group_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."auth_group_id_seq";
CREATE SEQUENCE "public"."auth_group_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for auth_group_permissions_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."auth_group_permissions_id_seq";
CREATE SEQUENCE "public"."auth_group_permissions_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for auth_permission_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."auth_permission_id_seq";
CREATE SEQUENCE "public"."auth_permission_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for django_admin_log_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."django_admin_log_id_seq";
CREATE SEQUENCE "public"."django_admin_log_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for django_content_type_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."django_content_type_id_seq";
CREATE SEQUENCE "public"."django_content_type_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for django_migrations_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."django_migrations_id_seq";
CREATE SEQUENCE "public"."django_migrations_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_acct_groups_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_acct_groups_id_seq";
CREATE SEQUENCE "public"."musicApp_acct_groups_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_acct_user_permissions_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_acct_user_permissions_id_seq";
CREATE SEQUENCE "public"."musicApp_acct_user_permissions_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_article_article_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_article_article_id_seq";
CREATE SEQUENCE "public"."musicApp_article_article_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_artmessage_mess_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_artmessage_mess_id_seq";
CREATE SEQUENCE "public"."musicApp_artmessage_mess_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_singer_singer_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_singer_singer_id_seq";
CREATE SEQUENCE "public"."musicApp_singer_singer_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for musicApp_song_song_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."musicApp_song_song_id_seq";
CREATE SEQUENCE "public"."musicApp_song_song_id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS "public"."auth_group";
CREATE TABLE "public"."auth_group" (
  "id" int4 NOT NULL DEFAULT nextval('auth_group_id_seq'::regclass),
  "name" varchar(150) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS "public"."auth_group_permissions";
CREATE TABLE "public"."auth_group_permissions" (
  "id" int8 NOT NULL DEFAULT nextval('auth_group_permissions_id_seq'::regclass),
  "group_id" int4 NOT NULL,
  "permission_id" int4 NOT NULL
)
;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS "public"."auth_permission";
CREATE TABLE "public"."auth_permission" (
  "id" int4 NOT NULL DEFAULT nextval('auth_permission_id_seq'::regclass),
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "content_type_id" int4 NOT NULL,
  "codename" varchar(100) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO "public"."auth_permission" VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO "public"."auth_permission" VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO "public"."auth_permission" VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO "public"."auth_permission" VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO "public"."auth_permission" VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO "public"."auth_permission" VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO "public"."auth_permission" VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO "public"."auth_permission" VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO "public"."auth_permission" VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO "public"."auth_permission" VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO "public"."auth_permission" VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO "public"."auth_permission" VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO "public"."auth_permission" VALUES (13, 'Can add content type', 4, 'add_contenttype');
INSERT INTO "public"."auth_permission" VALUES (14, 'Can change content type', 4, 'change_contenttype');
INSERT INTO "public"."auth_permission" VALUES (15, 'Can delete content type', 4, 'delete_contenttype');
INSERT INTO "public"."auth_permission" VALUES (16, 'Can view content type', 4, 'view_contenttype');
INSERT INTO "public"."auth_permission" VALUES (17, 'Can add session', 5, 'add_session');
INSERT INTO "public"."auth_permission" VALUES (18, 'Can change session', 5, 'change_session');
INSERT INTO "public"."auth_permission" VALUES (19, 'Can delete session', 5, 'delete_session');
INSERT INTO "public"."auth_permission" VALUES (20, 'Can view session', 5, 'view_session');
INSERT INTO "public"."auth_permission" VALUES (21, 'Can add user', 6, 'add_acct');
INSERT INTO "public"."auth_permission" VALUES (22, 'Can change user', 6, 'change_acct');
INSERT INTO "public"."auth_permission" VALUES (23, 'Can delete user', 6, 'delete_acct');
INSERT INTO "public"."auth_permission" VALUES (24, 'Can view user', 6, 'view_acct');
INSERT INTO "public"."auth_permission" VALUES (25, 'Can add singer', 7, 'add_singer');
INSERT INTO "public"."auth_permission" VALUES (26, 'Can change singer', 7, 'change_singer');
INSERT INTO "public"."auth_permission" VALUES (27, 'Can delete singer', 7, 'delete_singer');
INSERT INTO "public"."auth_permission" VALUES (28, 'Can view singer', 7, 'view_singer');
INSERT INTO "public"."auth_permission" VALUES (29, 'Can add song', 8, 'add_song');
INSERT INTO "public"."auth_permission" VALUES (30, 'Can change song', 8, 'change_song');
INSERT INTO "public"."auth_permission" VALUES (31, 'Can delete song', 8, 'delete_song');
INSERT INTO "public"."auth_permission" VALUES (32, 'Can view song', 8, 'view_song');
INSERT INTO "public"."auth_permission" VALUES (33, 'Can add article', 9, 'add_article');
INSERT INTO "public"."auth_permission" VALUES (34, 'Can change article', 9, 'change_article');
INSERT INTO "public"."auth_permission" VALUES (35, 'Can delete article', 9, 'delete_article');
INSERT INTO "public"."auth_permission" VALUES (36, 'Can view article', 9, 'view_article');
INSERT INTO "public"."auth_permission" VALUES (37, 'Can add art message', 10, 'add_artmessage');
INSERT INTO "public"."auth_permission" VALUES (38, 'Can change art message', 10, 'change_artmessage');
INSERT INTO "public"."auth_permission" VALUES (39, 'Can delete art message', 10, 'delete_artmessage');
INSERT INTO "public"."auth_permission" VALUES (40, 'Can view art message', 10, 'view_artmessage');

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS "public"."django_admin_log";
CREATE TABLE "public"."django_admin_log" (
  "id" int4 NOT NULL DEFAULT nextval('django_admin_log_id_seq'::regclass),
  "action_time" timestamptz(6) NOT NULL,
  "object_id" text COLLATE "pg_catalog"."default",
  "object_repr" varchar(200) COLLATE "pg_catalog"."default" NOT NULL,
  "action_flag" int2 NOT NULL,
  "change_message" text COLLATE "pg_catalog"."default" NOT NULL,
  "content_type_id" int4,
  "user_id" varchar(254) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------
INSERT INTO "public"."django_admin_log" VALUES (1, '2022-05-30 10:36:35.192521+00', '1', 'Singer object (1)', 1, '[{"added": {}}]', 7, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (2, '2022-05-30 10:36:52.666705+00', '2', 'Singer object (2)', 1, '[{"added": {}}]', 7, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (3, '2022-05-30 10:37:08.323643+00', '3', 'Singer object (3)', 1, '[{"added": {}}]', 7, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (4, '2022-05-30 10:53:19.401152+00', '1', 'Song object (1)', 1, '[{"added": {}}]', 8, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (5, '2022-05-30 10:53:56.504343+00', '2', 'Song object (2)', 1, '[{"added": {}}]', 8, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (6, '2022-05-30 18:41:18.965502+00', '1', 'Article object (1)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (7, '2022-05-30 18:42:20.312499+00', '2', 'Article object (2)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (8, '2022-05-30 18:43:01.742062+00', '3', 'Article object (3)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (9, '2022-05-30 18:44:25.34597+00', '4', 'Article object (4)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (10, '2022-05-30 18:45:24.072419+00', '5', 'Article object (5)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (11, '2022-05-30 18:46:17.49896+00', '6', 'Article object (6)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (12, '2022-05-30 18:47:47.704417+00', '7', 'Article object (7)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (13, '2022-05-30 18:48:46.82029+00', '8', 'Article object (8)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (14, '2022-05-30 18:50:06.264156+00', '9', 'Article object (9)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (15, '2022-05-30 18:51:13.354193+00', '10', 'Article object (10)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (16, '2022-05-30 18:52:12.627569+00', '11', 'Article object (11)', 1, '[{"added": {}}]', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (17, '2022-06-06 13:48:49.290119+00', '56', 'Article object (56)', 3, '', 9, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (18, '2022-06-06 13:49:57.820999+00', '13', 'ArtMessage object (13)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (19, '2022-06-06 13:49:58.087609+00', '14', 'ArtMessage object (14)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (20, '2022-06-06 13:49:58.317271+00', '15', 'ArtMessage object (15)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (21, '2022-06-06 13:49:58.549728+00', '16', 'ArtMessage object (16)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (22, '2022-06-06 13:49:58.782066+00', '17', 'ArtMessage object (17)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (23, '2022-06-06 13:49:59.015521+00', '19', 'ArtMessage object (19)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (24, '2022-06-06 13:49:59.263028+00', '20', 'ArtMessage object (20)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (25, '2022-06-06 13:49:59.496848+00', '21', 'ArtMessage object (21)', 3, '', 10, '11036008@ntub.edu.tw');
INSERT INTO "public"."django_admin_log" VALUES (26, '2022-06-06 13:49:59.736062+00', '22', 'ArtMessage object (22)', 3, '', 10, '11036008@ntub.edu.tw');

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS "public"."django_content_type";
CREATE TABLE "public"."django_content_type" (
  "id" int4 NOT NULL DEFAULT nextval('django_content_type_id_seq'::regclass),
  "app_label" varchar(100) COLLATE "pg_catalog"."default" NOT NULL,
  "model" varchar(100) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO "public"."django_content_type" VALUES (1, 'admin', 'logentry');
INSERT INTO "public"."django_content_type" VALUES (2, 'auth', 'permission');
INSERT INTO "public"."django_content_type" VALUES (3, 'auth', 'group');
INSERT INTO "public"."django_content_type" VALUES (4, 'contenttypes', 'contenttype');
INSERT INTO "public"."django_content_type" VALUES (5, 'sessions', 'session');
INSERT INTO "public"."django_content_type" VALUES (6, 'musicApp', 'acct');
INSERT INTO "public"."django_content_type" VALUES (7, 'musicApp', 'singer');
INSERT INTO "public"."django_content_type" VALUES (8, 'musicApp', 'song');
INSERT INTO "public"."django_content_type" VALUES (9, 'musicApp', 'article');
INSERT INTO "public"."django_content_type" VALUES (10, 'musicApp', 'artmessage');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS "public"."django_migrations";
CREATE TABLE "public"."django_migrations" (
  "id" int8 NOT NULL DEFAULT nextval('django_migrations_id_seq'::regclass),
  "app" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "applied" timestamptz(6) NOT NULL
)
;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO "public"."django_migrations" VALUES (1, 'contenttypes', '0001_initial', '2022-05-30 09:59:02.767013+00');
INSERT INTO "public"."django_migrations" VALUES (2, 'contenttypes', '0002_remove_content_type_name', '2022-05-30 09:59:04.091856+00');
INSERT INTO "public"."django_migrations" VALUES (3, 'auth', '0001_initial', '2022-05-30 09:59:10.662007+00');
INSERT INTO "public"."django_migrations" VALUES (4, 'auth', '0002_alter_permission_name_max_length', '2022-05-30 09:59:11.544949+00');
INSERT INTO "public"."django_migrations" VALUES (5, 'auth', '0003_alter_user_email_max_length', '2022-05-30 09:59:12.436509+00');
INSERT INTO "public"."django_migrations" VALUES (6, 'auth', '0004_alter_user_username_opts', '2022-05-30 09:59:13.319027+00');
INSERT INTO "public"."django_migrations" VALUES (7, 'auth', '0005_alter_user_last_login_null', '2022-05-30 09:59:14.212786+00');
INSERT INTO "public"."django_migrations" VALUES (8, 'auth', '0006_require_contenttypes_0002', '2022-05-30 09:59:15.093056+00');
INSERT INTO "public"."django_migrations" VALUES (9, 'auth', '0007_alter_validators_add_error_messages', '2022-05-30 09:59:15.979952+00');
INSERT INTO "public"."django_migrations" VALUES (10, 'auth', '0008_alter_user_username_max_length', '2022-05-30 09:59:16.864951+00');
INSERT INTO "public"."django_migrations" VALUES (11, 'auth', '0009_alter_user_last_name_max_length', '2022-05-30 09:59:17.754991+00');
INSERT INTO "public"."django_migrations" VALUES (12, 'auth', '0010_alter_group_name_max_length', '2022-05-30 09:59:18.870071+00');
INSERT INTO "public"."django_migrations" VALUES (13, 'auth', '0011_update_proxy_permissions', '2022-05-30 09:59:19.757692+00');
INSERT INTO "public"."django_migrations" VALUES (14, 'auth', '0012_alter_user_first_name_max_length', '2022-05-30 09:59:20.655878+00');
INSERT INTO "public"."django_migrations" VALUES (15, 'musicApp', '0001_initial', '2022-05-30 09:59:31.68154+00');
INSERT INTO "public"."django_migrations" VALUES (16, 'admin', '0001_initial', '2022-05-30 09:59:35.49632+00');
INSERT INTO "public"."django_migrations" VALUES (17, 'admin', '0002_logentry_remove_auto_add', '2022-05-30 09:59:36.183466+00');
INSERT INTO "public"."django_migrations" VALUES (18, 'admin', '0003_logentry_add_action_flag_choices', '2022-05-30 09:59:37.093032+00');
INSERT INTO "public"."django_migrations" VALUES (19, 'sessions', '0001_initial', '2022-05-30 09:59:39.381411+00');
INSERT INTO "public"."django_migrations" VALUES (20, 'musicApp', '0002_artmessage', '2022-05-30 14:18:43.289834+00');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS "public"."django_session";
CREATE TABLE "public"."django_session" (
  "session_key" varchar(40) COLLATE "pg_catalog"."default" NOT NULL,
  "session_data" text COLLATE "pg_catalog"."default" NOT NULL,
  "expire_date" timestamptz(6) NOT NULL
)
;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO "public"."django_session" VALUES ('m51kog81e06eltfps73q4undovhas2f9', '.eJx9jjsOwjAQRO_iGln2ElsOFaLnDNGu104C-UhxIgrE3bFRCmhoZ948zVM0uK1ds6WwND2Lk3iEtPKCrtYA-tyO2A_Sz6M4fJOE_h6mgvMNp3bOxLQuPcmCyL1N8jpzGC47-yPoMHVl7R0cDTFYT4oqG70yEQBq4xQxOsUuR_EYc6ArRiYgbYNXzrFha7P0owvl5p_zrzc8pE0N:1nxtK2:HrQkinrvC0wNTOpfi2u1nYjw8YEfC6AU6EtaS2EbONc', '2022-06-19 16:41:50.690433+00');
INSERT INTO "public"."django_session" VALUES ('yjm3aply9v9ae7sd80k1ozn6b9jehd7t', '.eJx1zj0OwjAMhuG7ZEaR80PjMiF2zlAlsUMLJZXaRgyIu9OiDjAw-_Gr7ykaX-a2KROPTUfiIJQCUwHgMc8lSKYi54fYfbPg443zaunq82WQccjz2AW5ErldJ3keiPvTZn8CrZ_a5duic0axDRhqtgkUgifLZFWNuE8maoCoDTvWpiZmSJpS8AgVOB0TLtFPju--6_8tf70BeJZI2w:1nymES:ZlX4dYR5iFo5qeQdB8rBnvJCWw3MotGKUmFWFacRA2Q', '2022-06-22 03:19:44.311354+00');
INSERT INTO "public"."django_session" VALUES ('5ywy4038tq2yzjr69dethjn9cacuiw2v', '.eJxVzMsOgjAQheF36do00yltrSvj3mcgM51yUYSEwsr47kLCQtfnO_9b1bQuXb2WPNe9qItKVLIxBgGv7Yv6QafppU6_jCk987hbedDYTpsYl7lnvRN9rEXfJ8nD7bB_gY5Kt72B0KDxEKN4RBOztWzRRoHE4MAGH11wHgUCc0MJ47mpKl-J5SBWnPp8ARnnPO8:1nzYJk:JAvru0xszxSJnWHpTAOvwEBuIkyYhMJVEDjv6NzvOrw', '2022-06-24 06:40:24.075549+00');
INSERT INTO "public"."django_session" VALUES ('hx9uhd9pwwdx19qbsz2xvql7ycusudd4', '.eJx1zj0OgzAMhuG7ZK6imNQEOlXsPQNyHAdo-ZEITFXvXqgY2qGzH7_6nqqmdWnrNclcd0FdFFMSAMhMdm0G6nrN06BO38wTP2TcbbjT2EybGJe583on-rgmfZuC9NVhfwItpXb7BmGP7FBKtI4hmmi4RDLonfUFUlaA9YTArrAImOdRApWOzt5FE8Bs0U9O9pn_lr_e6VVJnw:1o4de0:GaG14sl5F2-fpAo0NDMMJBep7bV5FlR5soPAPWWeXzU', '2022-07-08 07:22:20.475+00');
INSERT INTO "public"."django_session" VALUES ('f8c4kbur2hod12q35ulwizj8wd6rgg7t', '.eJx1jrEOwiAURf-F2RCg5RWcTHe_oXnAw1YrTVqIg_HfbU0HHZzPuSf3yTosue_KQnM3BHZkUmgNQshTysVxCoXnBzt8aw79jdLmhiumy8T9lPI8OL4pfKcLP0-BxnZ3fwI9Lv26BhGsFFUUDZmovLIKgCjWVkmjTYO0UWVBg7G6VhhVDJVA50GbWINdo58c3XEY_z1_vQE350fU:1oD7nH:CUDcQ0HymS8RrHTtTfxVxiPMK-mRFUqUj-IUAuSr89A', '2022-07-31 17:10:59.67264+00');
INSERT INTO "public"."django_session" VALUES ('9fyumw35fbcdrgl2jvosiuixf6skhwqi', '.eJxVzDsOwjAQBNC7uEbW7jrxhwrRc4ZonXVIADlSYosCcXcSiQKaaebNvFTHtYxdXdPSTaKOChGMBfCnXGrUSaouT3X4ZZH7e8q7lRvn66z7OZdlinon-tuu-jJLepy_9u9g5HXc1kDomuBajxhhy2iCJTExCDI7HMSAkA_E1A7OgrA0RAashIQDNF69P9cZPIE:1oEvUA:yfJrEwG-gnxt6m1ZTzXwPFPFjlwrlAdfepMZ4OzO3Zs', '2022-08-05 16:26:42.018326+00');

-- ----------------------------
-- Table structure for musicApp_acct
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_acct";
CREATE TABLE "public"."musicApp_acct" (
  "password" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "last_login" timestamptz(6),
  "is_superuser" bool NOT NULL,
  "first_name" varchar(150) COLLATE "pg_catalog"."default" NOT NULL,
  "last_name" varchar(150) COLLATE "pg_catalog"."default" NOT NULL,
  "is_staff" bool NOT NULL,
  "is_active" bool NOT NULL,
  "date_joined" timestamptz(6) NOT NULL,
  "email" varchar(254) COLLATE "pg_catalog"."default" NOT NULL,
  "username" varchar(10) COLLATE "pg_catalog"."default" NOT NULL,
  "update_time" date NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_acct
-- ----------------------------
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$mht1iI1AoTBwDBqrEELBON$f4mtFXWsnG6hkbSfQxIJOpzyvxo75n8ZSVQdXKGJ5zw=', '2022-06-09 15:57:30.992706+00', 'f', '', '', 'f', 't', '2022-06-03 09:58:33.716936+00', 'westdra891221@gmail.com', 'lin4587', '2022-06-03');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$KjWPRvGc2oqR74H96Tp6dv$0WgsVgTZONu9ssQ0Hcctgo5XxP/zHP17/O1wEmvB9Xw=', '2022-06-09 16:41:36.947383+00', 'f', '', '', 'f', 't', '2022-06-09 16:06:02.758743+00', '10556021@ntub.edu.tw', 'haha123', '2022-06-10');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$ypMRa5wiZ0zS910BDpwhaj$jk4XCYoNz6sAeSKdLRd+HIS5ZYU4M3egnl+4YT+B2fg=', NULL, 'f', '', '', 'f', 't', '2022-06-03 10:01:10.055752+00', '11036037@ntub.edu.tw', 'haha456', '2022-06-03');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$LxUkOcYTGj804ZHIQtbGp4$qdPp668TE2FWx34vVEj/GLiN7BOLirLjE3OeoVw5tds=', NULL, 'f', '', '', 'f', 't', '2022-06-24 07:19:15.791569+00', '12314@ntub.edu.tw', 'asd', '2022-06-24');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$kDsTVuhM3NUJhYLHu6FLkw$ZZUnSrePTmAse9XBKd8Oaqey3I67ogFy7hDR2pjxuP4=', '2022-06-24 07:19:36.25054+00', 'f', '', '', 'f', 't', '2022-05-30 10:05:49.723112+00', 'case111202@gmail.com', 'mary', '2022-06-10');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$eHLmW7Rb0AcYwFrszYDgHa$MbYmAKfcspxmSV1EyiQDaTO8EAYasfPZu6LiyMGasDo=', '2022-07-17 17:10:59.46427+00', 'f', '', '', 'f', 't', '2022-07-17 17:02:16.923896+00', '10556001@ntub.edu.tw', 'ohya1234', '2022-07-18');
INSERT INTO "public"."musicApp_acct" VALUES ('pbkdf2_sha256$260000$HljKlwe3BYxFuZH0w471t9$4jhXpsi9esPkIcwsCpk1TrFpi32c4c7aa3rAoCKNocY=', '2022-07-22 16:26:41.804956+00', 't', '', '', 't', 't', '2022-05-30 10:00:40.612901+00', '11036008@ntub.edu.tw', 'admin', '2022-06-10');

-- ----------------------------
-- Table structure for musicApp_acct_groups
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_acct_groups";
CREATE TABLE "public"."musicApp_acct_groups" (
  "id" int8 NOT NULL DEFAULT nextval('"musicApp_acct_groups_id_seq"'::regclass),
  "acct_id" varchar(254) COLLATE "pg_catalog"."default" NOT NULL,
  "group_id" int4 NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_acct_groups
-- ----------------------------

-- ----------------------------
-- Table structure for musicApp_acct_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_acct_user_permissions";
CREATE TABLE "public"."musicApp_acct_user_permissions" (
  "id" int8 NOT NULL DEFAULT nextval('"musicApp_acct_user_permissions_id_seq"'::regclass),
  "acct_id" varchar(254) COLLATE "pg_catalog"."default" NOT NULL,
  "permission_id" int4 NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_acct_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for musicApp_article
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_article";
CREATE TABLE "public"."musicApp_article" (
  "article_id" int4 NOT NULL DEFAULT nextval('"musicApp_article_article_id_seq"'::regclass),
  "article_context" text COLLATE "pg_catalog"."default",
  "draft_context" text COLLATE "pg_catalog"."default",
  "nick_name" varchar(10) COLLATE "pg_catalog"."default",
  "sendmail" bool,
  "sencla" varchar(1) COLLATE "pg_catalog"."default" NOT NULL,
  "rectime" date NOT NULL,
  "email_id" varchar(254) COLLATE "pg_catalog"."default" NOT NULL,
  "song_id_id" int4 NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_article
-- ----------------------------
INSERT INTO "public"."musicApp_article" VALUES (1, '最近有很喜歡的學長，他大三，我大一，是同個社團的，說不上特別熟，只有聊過幾次天，吃過一次飯，而且都是我主動，連他有沒有女友，喜不喜歡女生都不知道怎麼打聽，他很被動，如果我不講話，他絕對不會主動講話，因為他大三了，所以很怕他很快就要走，想要主動追他，但又很怕嚇走他他沒在用ig只有三個粉絲所以也不敢追蹤到底要怎麼追啊，真的好喜歡他喔。', '', NULL, 't', '喜', '2022-05-31', '11036008@ntub.edu.tw', 1);
INSERT INTO "public"."musicApp_article" VALUES (2, '', '就在今天，本來跟朋友在聊天，突然聊著聊著就聊到了我家住哪啊之類的，然後我也反問他，結果沒想到他居然住在我以前住過的地區，然後越問越深後，才發現我跟他居然有共同認識的同學，他還特地打電話去確認，然後我那個同學居然還知道我住在哪裡（真的太神了哈哈，其實我都忘記我住在哪裡了哈哈，然後聊著聊著就突然感嘆這世界確實很小，畢竟我都已經抱持著一輩子可能都不會見到面的想法了哈哈，但突然就發現居然有人認識他們，瞬間回憶就湧上心頭，雖然也只有短短的兩年啦，但在那段時間裡我很開心，也遇到了改變我一生的導師，只能說，緣分真的很神奇。', 'mary', NULL, '喜', '2022-05-31', 'case111202@gmail.com', 2);
INSERT INTO "public"."musicApp_article" VALUES (3, '大概兩年前我哥交了一個女友在交往的這兩年一開始會偶爾來住我們家覺得很ok畢竟有時候就是想跟男友一起住嘛我懂（我們是一家4口一起住）但是後來近一年半幾乎是每週都會來住？讓我覺得很奇怪是沒有自己的事要做嗎到底為什麼每個禮拜都一定要來住我們家好大家一定會覺得說：她也沒影響到你啊為什麼要有意見當然有意見，因為她來住的這兩天都會把內衣褲留在我們家洗？？？？？問號滿天。好那就算了但是都不會收好每次我的櫃子一定會出現她的內褲⋯（因為麻麻是家管所以會幫大家收衣服）而且應該已經發生很多次了⋯正常人應該會覺得尷尬拍謝這樣吧但是完全沒有要改善的意思還是堅持內衣褲要留在我家洗？像我自己有時住男友家我的衣服從來不會想在男友家洗真的覺得很困擾跟我哥反應很多次他也不以為意想問大家有遇過類似這樣的問題嗎⋯⋯這是我第一次發文有不妥的地方大家再跟我說。', '', 'admin', 't', '怒', '2022-05-31', '11036008@ntub.edu.tw', 3);
INSERT INTO "public"."musicApp_article" VALUES (6, '跟現任已經交往快5年了，在一起不到兩個月他就被外派到國外去，開始了一年兩會的遠距離，在一起一年後我也跟他坦白我希望30歲之前結婚生子（考慮帶孩子體力），但交往到第三年，他還沒要回台的打算，所以我退讓了，變成希望30歲之前結婚，35歲之前生孩子，現在我已經29了，也多次暗示他我想要有一個家，但他都打哈哈過去，我真的好累，因為疫情，變成一年見一次面，一次差不多3天，因為遠距離，我出車禍住院、生病住院、得憂鬱症，他都不在身邊，我只能一個人撐過來，從剛開始的想說撐個幾年就好，到現在變成，還要到底還要再幾年...朋友都說很佩服我，能夠這樣遠距離，我只能苦笑，他不回來啊....明明他超多同事因為疫情的關係趁機申請回台，但他就是不要，到最後我已經心冷的問他：你真的會回來嗎？他才哄哄我：會啊，我一定會回去的，：什麼時候？他不回答我，我想放手了。', '', NULL, 't', '哀', '2022-05-31', '11036008@ntub.edu.tw', 6);
INSERT INTO "public"."musicApp_article" VALUES (7, '跟男友在一起應該3年了吧XD
平常住一起，工作的關係需要出差，但因為疫情關係男友出差已經1年又3天了，雖然每天晚上都是彼此互通電話的時間，但總覺得少了什麼？
就目前狀況來說，完全沒有一個確定回來的時間，我很清楚這不是我要的生活，不知道要怎麼等下去。
每天腦中轉了千百回，很掙扎，也覺得痛苦加無奈，這段感情還能繼續走下去嗎？', '', NULL, 'f', '懼', '2022-05-31', 'case111202@gmail.com', 7);
INSERT INTO "public"."musicApp_article" VALUES (8, '我的感情一直都不順 差點被騙炮、告白失敗、對方只想曖昧不給承諾……
我父母的婚姻狀況也不好，總是吵架、分床睡只差沒離婚。
就算世間很險惡 不能事事如意，但我也不想放棄勇敢去愛的勇氣。

我相信一定會遇到跟我有著相同感情觀和目標的人。
在每一次的難過失望中更了解自己，
在每一次的挫折受傷中去修正自己。

最重要的是，我不想被誰和世界改變我自己，不想要輸給那個誰與被這個世界打敗
我要堅持自己所堅持的，相信自己所相信的，所以我會在追求感情的路上繼續努力。

希望在感情中被劈腿、被欺騙、被傷害的你，在療傷後 也能重新相信愛你的人一定會出現。

因為這世上有像你我一樣善良的人、一樣如此深信著的人。

如果因為自己受了傷而選擇去傷害下一個人，那只會變得永遠都不相信愛情，因為連你自己都做不到真誠了，就不會相信別人能給你。

所以不要覺得自己永遠都得不到愛了，好嗎？', '', 'admin', 't', '愛', '2022-05-31', '11036008@ntub.edu.tw', 8);
INSERT INTO "public"."musicApp_article" VALUES (9, '想告訴在感情路上不順遂的你/妳，千萬不要放棄愛情，也不要因為那個傷害你、背叛你的人傷心難過，人生的路還很長。
總有一天，一定會遇到適合自己，而且很愛你的人。', '', 'mary', 't', '愛', '2022-05-31', 'case111202@gmail.com', 9);
INSERT INTO "public"."musicApp_article" VALUES (11, '在去年我靠推甄上了四大的某工學院研究所，我的天我爸媽直接變了風向呢!開始瘋狂跟別人說我很厲害，還講什麼小孩子有興趣讀書就應該要支持她們。
大學四年從沒感受到你們支持過我，只有我努力撐住我自己好嗎?
從小到大除了讀書之外其他方面都被你們嫌棄的要死，說我懶惰，做事情反應慢又遲鈍，我爸還說過我活著當人有什麼意義呢?
從小對家庭的情感就很淡了，原本想試著在大學期間感受別人說的，大學會想家懷念家的好，現在只覺得自己在外面住真好。', '', NULL, 't', '恨', '2022-05-31', '11036008@ntub.edu.tw', 12);
INSERT INTO "public"."musicApp_article" VALUES (4, '我真的不懂為什麼告白被拒絕後彼此要變的尷尬 甚至連朋友都當不成了 會這麼想的人在想什麼？', '', NULL, 'f', '怒', '2022-05-23', 'case111202@gmail.com', 4);
INSERT INTO "public"."musicApp_article" VALUES (10, '有事不跟處理的人說是在哈囉!
昨天還好像做事很有方法一樣，就不要等等又不爽 幹。
唉 社畜可憐哪...，就算我快滾了。
今天還是我負責處理這件事好嗎?
總之就是幹，再補一億個幹。', '', 'mary', 'f', '恨', '2022-05-26', 'case111202@gmail.com', 11);
INSERT INTO "public"."musicApp_article" VALUES (5, '', '當你說不的那一刻我就知道我們沒有結果了，連朋友也當不成了，我真的覺得自己好傻喔，去喜歡一個不喜歡自己的人，身邊的人都告訴我你不喜歡我，而我卻以為你只是用不一樣的方式來跟我相處而已，我每次要放下你時都告訴自己你只是還沒放下前任而已，然後刪了所有訊息，然後你傳訊息來時我又打臉了自己又繼續回你，但時間等啊等..到後面難過的卻是自己每天都期待你主動密我或是回我訊息，但最後卻是一場空，我只能說我曾經喜歡過你，只是我們的相遇卻是在不對的時間，希望打完這篇文後我明天還是能繼續振作起來！小丑笑著笑著最後就哭了......', 'mary', NULL, '哀', '2022-05-23', 'case111202@gmail.com', 10);
INSERT INTO "public"."musicApp_article" VALUES (122, '有一次跟他吃飯，吃完飯要回家時碰上毛毛雨。
由於他送我去捷運站途中是一整排騎樓
其實不太需要撐傘。
不過，騎樓與騎樓間總會有一小段路
就那麼幾步可以走完，但上方無遮蔽物
多多少少會淋到幾滴雨。
正常人會不以為意的快步走過，他卻做了一件偶像劇男主角才會做的事。
那就是，在會淋到雨的每一小段路，他都用雙手遮在我頭頂上方幫忙擋雨。
沒錯，就是偶像劇才有的情節！
傳說中的，手！掌！傘！
真真實實就發生在我身上啊啊啊啊
這個浪漫指數超級高～～～
當下心臟一個活蹦亂跳，以為自己在做夢
怎麼會有人這麼貼心！', '', 'mary', 't', '愛', '2022-06-10', 'case111202@gmail.com', 10);
INSERT INTO "public"."musicApp_article" VALUES (123, '有一次跟他吃飯，吃完飯要回家時碰上毛毛雨。
由於他送我去捷運站途中是一整排騎樓
其實不太需要撐傘。
不過，騎樓與騎樓間總會有一小段路
就那麼幾步可以走完，但上方無遮蔽物
多多少少會淋到幾滴雨。
正常人會不以為意的快步走過，他卻做了一件偶像劇男主角才會做的事。', '', 'mary', 't', '愛', '2022-06-24', 'case111202@gmail.com', 10);

-- ----------------------------
-- Table structure for musicApp_artmessage
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_artmessage";
CREATE TABLE "public"."musicApp_artmessage" (
  "mess_id" int4 NOT NULL DEFAULT nextval('"musicApp_artmessage_mess_id_seq"'::regclass),
  "mess_context" text COLLATE "pg_catalog"."default",
  "mess_date" date NOT NULL,
  "article_id_id" int4 NOT NULL,
  "email_id" varchar(254) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_artmessage
-- ----------------------------
INSERT INTO "public"."musicApp_artmessage" VALUES (57, '相信自己你一定可以的!', '2022-06-09', 1, 'case111202@gmail.com');
INSERT INTO "public"."musicApp_artmessage" VALUES (58, '他是一個很好的人', '2022-06-09', 1, 'westdra891221@gmail.com');
INSERT INTO "public"."musicApp_artmessage" VALUES (62, '他是一個很好的人', '2022-06-10', 122, 'case111202@gmail.com');
INSERT INTO "public"."musicApp_artmessage" VALUES (23, '加油加油加油GOGO!', '2022-06-06', 1, 'case111202@gmail.com');

-- ----------------------------
-- Table structure for musicApp_singer
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_singer";
CREATE TABLE "public"."musicApp_singer" (
  "singer_id" int4 NOT NULL DEFAULT nextval('"musicApp_singer_singer_id_seq"'::regclass),
  "singer_name" varchar(30) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_singer
-- ----------------------------
INSERT INTO "public"."musicApp_singer" VALUES (1, '田馥甄');
INSERT INTO "public"."musicApp_singer" VALUES (2, '黃鴻升');
INSERT INTO "public"."musicApp_singer" VALUES (3, '周湯豪');
INSERT INTO "public"."musicApp_singer" VALUES (4, '陳忻玥');
INSERT INTO "public"."musicApp_singer" VALUES (5, '蕭秉治');
INSERT INTO "public"."musicApp_singer" VALUES (6, '周興哲');
INSERT INTO "public"."musicApp_singer" VALUES (7, '告五人');
INSERT INTO "public"."musicApp_singer" VALUES (8, '茄子蛋');
INSERT INTO "public"."musicApp_singer" VALUES (9, '古曜威');
INSERT INTO "public"."musicApp_singer" VALUES (10, '邱軍');
INSERT INTO "public"."musicApp_singer" VALUES (11, '玖壹壹');

-- ----------------------------
-- Table structure for musicApp_song
-- ----------------------------
DROP TABLE IF EXISTS "public"."musicApp_song";
CREATE TABLE "public"."musicApp_song" (
  "song_id" int4 NOT NULL DEFAULT nextval('"musicApp_song_song_id_seq"'::regclass),
  "richi" date NOT NULL,
  "song_name" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "link" varchar(200) COLLATE "pg_catalog"."default" NOT NULL,
  "sentim_class" varchar(1) COLLATE "pg_catalog"."default" NOT NULL,
  "singer_id_id" int4 NOT NULL
)
;

-- ----------------------------
-- Records of musicApp_song
-- ----------------------------
INSERT INTO "public"."musicApp_song" VALUES (1, '2015-07-21', '小幸運', 'https://www.youtube.com/watch?v=_sQSXwdtxlY', '喜', 1);
INSERT INTO "public"."musicApp_song" VALUES (2, '2013-05-10', '超有感', 'https://www.youtube.com/watch?v=PI7b8rI2iR0', '喜', 2);
INSERT INTO "public"."musicApp_song" VALUES (3, '2022-01-07', '愛上你算我賤', 'https://www.youtube.com/watch?v=8urFHH4lPUg', '怒', 3);
INSERT INTO "public"."musicApp_song" VALUES (4, '2022-04-11', '你夠了', 'https://www.youtube.com/watch?v=lxBvTOaSVGM', '怒', 4);
INSERT INTO "public"."musicApp_song" VALUES (5, '2022-05-15', '都是我的錯', 'https://www.youtube.com/watch?v=0Rw8fe_K8H4', '哀', 5);
INSERT INTO "public"."musicApp_song" VALUES (6, '2021-10-30', '你不屬於我', 'https://www.youtube.com/watch?v=6O_Zx9St9ik', '哀', 6);
INSERT INTO "public"."musicApp_song" VALUES (7, '2021-01-04', '在這座城市遺失了你', 'https://www.youtube.com/watch?v=PlCbgZxonJs', '懼', 7);
INSERT INTO "public"."musicApp_song" VALUES (8, '2021-12-10', '閤愛你一擺', 'https://www.youtube.com/watch?v=PJJhHihvDpo', '愛', 8);
INSERT INTO "public"."musicApp_song" VALUES (9, '2022-04-20', '我還是愛你的', 'https://www.youtube.com/watch?v=QuDvgTMz4yQ', '愛', 9);
INSERT INTO "public"."musicApp_song" VALUES (10, '2011-11-28', '地球上最浪漫的一首歌', 'https://www.youtube.com/watch?v=bCB_nIdN86s', '愛', 2);
INSERT INTO "public"."musicApp_song" VALUES (11, '2022-05-13', '不是不會痛', 'https://www.youtube.com/watch?v=BLN7AX4f6L8s', '恨', 10);
INSERT INTO "public"."musicApp_song" VALUES (12, '2021-09-11', '癡人說夢', 'https://www.youtube.com/watch?v=KKbdUiBeYGU
', '恨', 11);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."auth_group_id_seq"
OWNED BY "public"."auth_group"."id";
SELECT setval('"public"."auth_group_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."auth_group_permissions_id_seq"
OWNED BY "public"."auth_group_permissions"."id";
SELECT setval('"public"."auth_group_permissions_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."auth_permission_id_seq"
OWNED BY "public"."auth_permission"."id";
SELECT setval('"public"."auth_permission_id_seq"', 41, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."django_admin_log_id_seq"
OWNED BY "public"."django_admin_log"."id";
SELECT setval('"public"."django_admin_log_id_seq"', 27, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."django_content_type_id_seq"
OWNED BY "public"."django_content_type"."id";
SELECT setval('"public"."django_content_type_id_seq"', 11, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."django_migrations_id_seq"
OWNED BY "public"."django_migrations"."id";
SELECT setval('"public"."django_migrations_id_seq"', 21, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_acct_groups_id_seq"
OWNED BY "public"."musicApp_acct_groups"."id";
SELECT setval('"public"."musicApp_acct_groups_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_acct_user_permissions_id_seq"
OWNED BY "public"."musicApp_acct_user_permissions"."id";
SELECT setval('"public"."musicApp_acct_user_permissions_id_seq"', 2, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_article_article_id_seq"
OWNED BY "public"."musicApp_article"."article_id";
SELECT setval('"public"."musicApp_article_article_id_seq"', 124, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_artmessage_mess_id_seq"
OWNED BY "public"."musicApp_artmessage"."mess_id";
SELECT setval('"public"."musicApp_artmessage_mess_id_seq"', 63, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_singer_singer_id_seq"
OWNED BY "public"."musicApp_singer"."singer_id";
SELECT setval('"public"."musicApp_singer_singer_id_seq"', 4, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."musicApp_song_song_id_seq"
OWNED BY "public"."musicApp_song"."song_id";
SELECT setval('"public"."musicApp_song_song_id_seq"', 3, true);

-- ----------------------------
-- Indexes structure for table auth_group
-- ----------------------------
CREATE INDEX "auth_group_name_a6ea08ec_like" ON "public"."auth_group" USING btree (
  "name" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table auth_group
-- ----------------------------
ALTER TABLE "public"."auth_group" ADD CONSTRAINT "auth_group_name_key" UNIQUE ("name");

-- ----------------------------
-- Primary Key structure for table auth_group
-- ----------------------------
ALTER TABLE "public"."auth_group" ADD CONSTRAINT "auth_group_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table auth_group_permissions
-- ----------------------------
CREATE INDEX "auth_group_permissions_group_id_b120cbf9" ON "public"."auth_group_permissions" USING btree (
  "group_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "auth_group_permissions_permission_id_84c5c92e" ON "public"."auth_group_permissions" USING btree (
  "permission_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table auth_group_permissions
-- ----------------------------
ALTER TABLE "public"."auth_group_permissions" ADD CONSTRAINT "auth_group_permissions_group_id_permission_id_0cd325b0_uniq" UNIQUE ("group_id", "permission_id");

-- ----------------------------
-- Primary Key structure for table auth_group_permissions
-- ----------------------------
ALTER TABLE "public"."auth_group_permissions" ADD CONSTRAINT "auth_group_permissions_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table auth_permission
-- ----------------------------
CREATE INDEX "auth_permission_content_type_id_2f476e4b" ON "public"."auth_permission" USING btree (
  "content_type_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table auth_permission
-- ----------------------------
ALTER TABLE "public"."auth_permission" ADD CONSTRAINT "auth_permission_content_type_id_codename_01ab375a_uniq" UNIQUE ("content_type_id", "codename");

-- ----------------------------
-- Primary Key structure for table auth_permission
-- ----------------------------
ALTER TABLE "public"."auth_permission" ADD CONSTRAINT "auth_permission_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table django_admin_log
-- ----------------------------
CREATE INDEX "django_admin_log_content_type_id_c4bce8eb" ON "public"."django_admin_log" USING btree (
  "content_type_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "django_admin_log_user_id_c564eba6" ON "public"."django_admin_log" USING btree (
  "user_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "django_admin_log_user_id_c564eba6_like" ON "public"."django_admin_log" USING btree (
  "user_id" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);

-- ----------------------------
-- Checks structure for table django_admin_log
-- ----------------------------
ALTER TABLE "public"."django_admin_log" ADD CONSTRAINT "django_admin_log_action_flag_check" CHECK (action_flag >= 0);

-- ----------------------------
-- Primary Key structure for table django_admin_log
-- ----------------------------
ALTER TABLE "public"."django_admin_log" ADD CONSTRAINT "django_admin_log_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table django_content_type
-- ----------------------------
ALTER TABLE "public"."django_content_type" ADD CONSTRAINT "django_content_type_app_label_model_76bd3d3b_uniq" UNIQUE ("app_label", "model");

-- ----------------------------
-- Primary Key structure for table django_content_type
-- ----------------------------
ALTER TABLE "public"."django_content_type" ADD CONSTRAINT "django_content_type_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table django_migrations
-- ----------------------------
ALTER TABLE "public"."django_migrations" ADD CONSTRAINT "django_migrations_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table django_session
-- ----------------------------
CREATE INDEX "django_session_expire_date_a5c62663" ON "public"."django_session" USING btree (
  "expire_date" "pg_catalog"."timestamptz_ops" ASC NULLS LAST
);
CREATE INDEX "django_session_session_key_c0390e0f_like" ON "public"."django_session" USING btree (
  "session_key" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table django_session
-- ----------------------------
ALTER TABLE "public"."django_session" ADD CONSTRAINT "django_session_pkey" PRIMARY KEY ("session_key");

-- ----------------------------
-- Indexes structure for table musicApp_acct
-- ----------------------------
CREATE INDEX "musicApp_acct_email_38084125_like" ON "public"."musicApp_acct" USING btree (
  "email" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table musicApp_acct
-- ----------------------------
ALTER TABLE "public"."musicApp_acct" ADD CONSTRAINT "musicApp_acct_pkey" PRIMARY KEY ("email");

-- ----------------------------
-- Indexes structure for table musicApp_acct_groups
-- ----------------------------
CREATE INDEX "musicApp_acct_groups_acct_id_ffd25810" ON "public"."musicApp_acct_groups" USING btree (
  "acct_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_acct_groups_acct_id_ffd25810_like" ON "public"."musicApp_acct_groups" USING btree (
  "acct_id" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_acct_groups_group_id_9b8c68a7" ON "public"."musicApp_acct_groups" USING btree (
  "group_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table musicApp_acct_groups
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_groups" ADD CONSTRAINT "musicApp_acct_groups_acct_id_group_id_d4dd9473_uniq" UNIQUE ("acct_id", "group_id");

-- ----------------------------
-- Primary Key structure for table musicApp_acct_groups
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_groups" ADD CONSTRAINT "musicApp_acct_groups_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table musicApp_acct_user_permissions
-- ----------------------------
CREATE INDEX "musicApp_acct_user_permissions_acct_id_436bb48b" ON "public"."musicApp_acct_user_permissions" USING btree (
  "acct_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_acct_user_permissions_acct_id_436bb48b_like" ON "public"."musicApp_acct_user_permissions" USING btree (
  "acct_id" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_acct_user_permissions_permission_id_5a894ed6" ON "public"."musicApp_acct_user_permissions" USING btree (
  "permission_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table musicApp_acct_user_permissions
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_user_permissions" ADD CONSTRAINT "musicApp_acct_user_permi_acct_id_permission_id_fc7b9e12_uniq" UNIQUE ("acct_id", "permission_id");

-- ----------------------------
-- Primary Key structure for table musicApp_acct_user_permissions
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_user_permissions" ADD CONSTRAINT "musicApp_acct_user_permissions_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table musicApp_article
-- ----------------------------
CREATE INDEX "musicApp_article_email_id_4e1a63ee" ON "public"."musicApp_article" USING btree (
  "email_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_article_email_id_4e1a63ee_like" ON "public"."musicApp_article" USING btree (
  "email_id" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_article_song_id_id_86d05f4a" ON "public"."musicApp_article" USING btree (
  "song_id_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table musicApp_article
-- ----------------------------
ALTER TABLE "public"."musicApp_article" ADD CONSTRAINT "musicApp_article_pkey" PRIMARY KEY ("article_id");

-- ----------------------------
-- Indexes structure for table musicApp_artmessage
-- ----------------------------
CREATE INDEX "musicApp_artmessage_article_id_id_2693d136" ON "public"."musicApp_artmessage" USING btree (
  "article_id_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_artmessage_email_id_318a0f49" ON "public"."musicApp_artmessage" USING btree (
  "email_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "musicApp_artmessage_email_id_318a0f49_like" ON "public"."musicApp_artmessage" USING btree (
  "email_id" COLLATE "pg_catalog"."default" "pg_catalog"."varchar_pattern_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table musicApp_artmessage
-- ----------------------------
ALTER TABLE "public"."musicApp_artmessage" ADD CONSTRAINT "musicApp_artmessage_pkey" PRIMARY KEY ("mess_id");

-- ----------------------------
-- Primary Key structure for table musicApp_singer
-- ----------------------------
ALTER TABLE "public"."musicApp_singer" ADD CONSTRAINT "musicApp_singer_pkey" PRIMARY KEY ("singer_id");

-- ----------------------------
-- Indexes structure for table musicApp_song
-- ----------------------------
CREATE INDEX "musicApp_song_singer_id_id_ba04b942" ON "public"."musicApp_song" USING btree (
  "singer_id_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table musicApp_song
-- ----------------------------
ALTER TABLE "public"."musicApp_song" ADD CONSTRAINT "musicApp_song_pkey" PRIMARY KEY ("song_id");

-- ----------------------------
-- Foreign Keys structure for table auth_group_permissions
-- ----------------------------
ALTER TABLE "public"."auth_group_permissions" ADD CONSTRAINT "auth_group_permissio_permission_id_84c5c92e_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "public"."auth_permission" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."auth_group_permissions" ADD CONSTRAINT "auth_group_permissions_group_id_b120cbf9_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "public"."auth_group" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table auth_permission
-- ----------------------------
ALTER TABLE "public"."auth_permission" ADD CONSTRAINT "auth_permission_content_type_id_2f476e4b_fk_django_co" FOREIGN KEY ("content_type_id") REFERENCES "public"."django_content_type" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table django_admin_log
-- ----------------------------
ALTER TABLE "public"."django_admin_log" ADD CONSTRAINT "django_admin_log_content_type_id_c4bce8eb_fk_django_co" FOREIGN KEY ("content_type_id") REFERENCES "public"."django_content_type" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."django_admin_log" ADD CONSTRAINT "django_admin_log_user_id_c564eba6_fk_musicApp_acct_email" FOREIGN KEY ("user_id") REFERENCES "public"."musicApp_acct" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table musicApp_acct_groups
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_groups" ADD CONSTRAINT "musicApp_acct_groups_acct_id_ffd25810_fk_musicApp_acct_email" FOREIGN KEY ("acct_id") REFERENCES "public"."musicApp_acct" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."musicApp_acct_groups" ADD CONSTRAINT "musicApp_acct_groups_group_id_9b8c68a7_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "public"."auth_group" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table musicApp_acct_user_permissions
-- ----------------------------
ALTER TABLE "public"."musicApp_acct_user_permissions" ADD CONSTRAINT "musicApp_acct_user_p_acct_id_436bb48b_fk_musicApp_" FOREIGN KEY ("acct_id") REFERENCES "public"."musicApp_acct" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."musicApp_acct_user_permissions" ADD CONSTRAINT "musicApp_acct_user_p_permission_id_5a894ed6_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "public"."auth_permission" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table musicApp_article
-- ----------------------------
ALTER TABLE "public"."musicApp_article" ADD CONSTRAINT "musicApp_article_email_id_4e1a63ee_fk_musicApp_acct_email" FOREIGN KEY ("email_id") REFERENCES "public"."musicApp_acct" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."musicApp_article" ADD CONSTRAINT "musicApp_article_song_id_id_86d05f4a_fk_musicApp_song_song_id" FOREIGN KEY ("song_id_id") REFERENCES "public"."musicApp_song" ("song_id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table musicApp_artmessage
-- ----------------------------
ALTER TABLE "public"."musicApp_artmessage" ADD CONSTRAINT "musicApp_artmessage_article_id_id_2693d136_fk_musicApp_" FOREIGN KEY ("article_id_id") REFERENCES "public"."musicApp_article" ("article_id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE "public"."musicApp_artmessage" ADD CONSTRAINT "musicApp_artmessage_email_id_318a0f49_fk_musicApp_acct_email" FOREIGN KEY ("email_id") REFERENCES "public"."musicApp_acct" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;

-- ----------------------------
-- Foreign Keys structure for table musicApp_song
-- ----------------------------
ALTER TABLE "public"."musicApp_song" ADD CONSTRAINT "musicApp_song_singer_id_id_ba04b942_fk_musicApp_" FOREIGN KEY ("singer_id_id") REFERENCES "public"."musicApp_singer" ("singer_id") ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;
