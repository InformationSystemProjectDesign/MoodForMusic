from rest_framework import serializers
from musicApp.models import Singer,Article,Acct


class SingerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Singer
        fields = ['singer_id','singer_name']

class UserSerializer(serializers.Serializer):
    email = serializers.EmailField() 
    username = serializers.CharField()
    password = serializers.CharField() 

class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField() 
    password = serializers.CharField()

class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = '__all__'

    