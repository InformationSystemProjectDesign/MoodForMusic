from rest_framework import viewsets
from musicApp.models import Singer,Acct,Article
from musicApp.api.serializers import SingerSerializer,UserSerializer, LoginSerializer,ArticleSerializer
from rest_framework.response import Response
from rest_framework.decorators import action
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

class SingerViewSet(viewsets.ModelViewSet):
    """
    A simple ViewSet for viewing and editing accounts.
    """
    queryset = Singer.objects.all()
    serializer_class = SingerSerializer

class UserViewSet(viewsets.GenericViewSet):

    queryset = Acct.objects.all()
    serializer_class = UserSerializer

    @action(
        methods = ["POST"], detail = False, url_path = "add-user"
    )
    def add_user(self, request):
        serializer = self.get_serializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.data["email"]
        username = serializer.data["username"]
        password = serializer.data["password"]
        acct = Acct.objects.create_user(username = username,email = email,password = password)
        
        return Response(data={"message":"add success"})

    @action(
         methods = ["POST"], detail = False, url_path = "login"
    )
    def login(self, request):
        serializer = LoginSerializer(data = request.data)
        serializer.is_valid(raise_exception = True)

        email = serializer.data["email"]
        password = serializer.data["password"]

        acct = authenticate(request,email = email,password = password)
        if acct:
            token = get_tokens_for_user(acct)
            return Response(data={"result":"login success","token":token["access"]})
        else:
            return Response(data={"result":"login fail"})

    @action(
         methods = ["GET"], detail = False, url_path = "test", permission_classes=[IsAuthenticated]
    )
    def test(self,request):
        return Response(data={"result":"test"})


class ArticleViewSet(viewsets.ModelViewSet):
    """
    A simple ViewSet for viewing and editing accounts.
    """
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer

   